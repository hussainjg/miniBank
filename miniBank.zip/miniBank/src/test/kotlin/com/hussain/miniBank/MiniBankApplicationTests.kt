package com.hussain.miniBank

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class MiniBankApplicationTests {

	@Test
	fun contextLoads() {
	}

}
